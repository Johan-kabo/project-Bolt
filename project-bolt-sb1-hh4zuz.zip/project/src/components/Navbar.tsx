import { ShoppingCart, Search } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { cartItems } = useCart();
  
  return (
    <nav className="bg-white shadow-lg fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex-shrink-0 flex items-center">
            <h1 className="text-2xl font-bold text-gray-800">ShoePalace</h1>
          </div>
          
          <div className="flex items-center">
            <div className="hidden md:block">
              <div className="flex items-center space-x-4">
                <a href="#" className="text-gray-600 hover:text-gray-900 px-3 py-2">Home</a>
                <a href="#" className="text-gray-600 hover:text-gray-900 px-3 py-2">Men</a>
                <a href="#" className="text-gray-600 hover:text-gray-900 px-3 py-2">Women</a>
                <a href="#" className="text-gray-600 hover:text-gray-900 px-3 py-2">Sale</a>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button className="text-gray-600 hover:text-gray-900">
              <Search className="h-6 w-6" />
            </button>
            <button className="text-gray-600 hover:text-gray-900 relative">
              <ShoppingCart className="h-6 w-6" />
              {cartItems.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {cartItems.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}