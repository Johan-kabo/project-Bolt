import { Shoe } from '../types';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  shoe: Shoe;
}

export default function ProductCard({ shoe }: ProductCardProps) {
  const { addToCart } = useCart();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <img 
        src={shoe.image} 
        alt={shoe.name} 
        className="w-full h-64 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800">{shoe.name}</h3>
        <p className="text-gray-600 text-sm mb-2">{shoe.category}</p>
        <p className="text-gray-800 font-bold">${shoe.price}</p>
        <button 
          onClick={() => addToCart(shoe, shoe.sizes[0])}
          className="mt-4 w-full bg-black text-white py-2 rounded-md hover:bg-gray-800 transition"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}