export const shoes = [
  {
    id: 1,
    name: "Air Sport Runner",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",
    category: "Running",
    sizes: [7, 8, 9, 10, 11],
    description: "Premium running shoes with advanced cushioning technology."
  },
  {
    id: 2,
    name: "Urban Street Classic",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772",
    category: "Casual",
    sizes: [6, 7, 8, 9, 10],
    description: "Stylish everyday sneakers for the modern lifestyle."
  },
  {
    id: 3,
    name: "Pro Basketball Elite",
    price: 159.99,
    image: "https://images.unsplash.com/photo-1579338559194-a162d19bf842",
    category: "Basketball",
    sizes: [8, 9, 10, 11, 12],
    description: "High-performance basketball shoes for serious players."
  },
  {
    id: 4,
    name: "Comfort Walker",
    price: 79.99,
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a",
    category: "Walking",
    sizes: [7, 8, 9, 10],
    description: "Comfortable walking shoes for daily use."
  }
];