export interface Shoe {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  sizes: number[];
  description: string;
}

export interface CartItem extends Shoe {
  quantity: number;
  selectedSize: number;
}